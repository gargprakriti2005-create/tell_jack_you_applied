function cleanTitle(title) {
  return (title || "").replace(/\s+/g, " ").trim().slice(0, 180);
}

async function getCurrentTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs.length ? tabs[0] : null;
}

function guessJobTitle(tab) {
  const title = cleanTitle(tab?.title || "");
  if (!title) return "Job application";
  return title
    .replace(/\s*[|–—-]\s*(LinkedIn|Greenhouse|Lever|Ashby|Workday|Indeed|Welcome to the Jungle).*$/i, "")
    .trim() || title;
}

function setStatus(message, kind = "normal") {
  const el = document.getElementById("ok");
  el.textContent = message;
  el.style.display = "block";
  el.style.color = kind === "error" ? "#b42318" : "#188038";
}

async function render() {
  try {
    const tab = await getCurrentTab();
    const title = guessJobTitle(tab);
    const url = tab?.url || "";
    let host = "";
    try { host = new URL(url).hostname; } catch {}
    document.getElementById("title").textContent = title;
    document.getElementById("site").textContent = host ? `${host} • ${url}` : url;

    const data = await chrome.storage.local.get({ pendingApplications: [] });
    document.getElementById("count").textContent = data.pendingApplications.length;
  } catch (err) {
    setStatus(`Extension error: ${err.message || err}`, "error");
  }
}

document.getElementById("save").addEventListener("click", async () => {
  const button = document.getElementById("save");
  button.disabled = true;
  button.textContent = "Saving…";

  try {
    const tab = await getCurrentTab();

    if (!tab || !tab.url || !/^https?:/i.test(tab.url)) {
      throw new Error("Please use the extension on a normal http/https job page.");
    }

    const note = document.getElementById("note").value.trim();
    const title = guessJobTitle(tab);

    let company = "";
    try {
      company = new URL(tab.url).hostname.replace(/^www\./, "");
    } catch {}

    const application = {
      id: String(Date.now()) + "-" + Math.random().toString(36).slice(2),
      title,
      company,
      url: tab.url,
      note,
      appliedAt: new Date().toISOString()
    };

    const data = await chrome.storage.local.get({ pendingApplications: [] });
    const existing = Array.isArray(data.pendingApplications) ? data.pendingApplications : [];

    if (!existing.some(x => x.url === application.url)) {
      existing.push(application);
      await chrome.storage.local.set({ pendingApplications: existing });
    }

    // Read back immediately so we know the save really happened.
    const verify = await chrome.storage.local.get({ pendingApplications: [] });
    const count = verify.pendingApplications.length;

    document.getElementById("count").textContent = count;
    setStatus(
      existing.some(x => x.id === application.id)
        ? "✓ Saved! Jack will be offered this update next time you open Jack."
        : "✓ Already saved — no duplicate created."
    );

    button.textContent = "Saved ✓";
  } catch (err) {
    setStatus(`Couldn't save: ${err.message || err}`, "error");
    button.disabled = false;
    button.textContent = "✓ I applied";
  }
});

render();