(() => {
  const ID = "jack-auto-submitted-prompt";
  const STORAGE_KEY = "autoSubmittedSeen";
  let alreadyChecked = false;

  function text() {
    return (document.body?.innerText || "").replace(/\s+/g, " ").trim();
  }

  function looksLikeJobSite() {
    const host = location.hostname.toLowerCase();
    const path = location.pathname.toLowerCase();
    const title = (document.title || "").toLowerCase();
    const hay = `${host} ${path} ${title}`;

    // Common ATS/job/application platforms. Also allow pages whose URL/title
    // clearly contains job/application language.
    const known = [
      "greenhouse", "lever.co", "ashbyhq", "workday", "myworkdayjobs",
      "smartrecruiters", "jobvite", "icims", "recruitee", "workable",
      "breezy.hr", "applytojob", "rippling", "teamtailor", "pinpoint",
      "linkedin.com/jobs", "indeed.com", "glassdoor"
    ];
    return known.some(x => hay.includes(x)) ||
      /\b(job|jobs|career|careers|application|apply|position|vacanc|recruit)\b/i.test(hay);
  }

  function looksSubmitted() {
    const t = text();
    if (!t) return false;

    const strong = [
      "application submitted",
      "application has been submitted",
      "your application was submitted",
      "your application has been submitted",
      "application successfully submitted",
      "successfully submitted",
      "thanks for applying",
      "thank you for applying",
      "thank you for your application",
      "we've received your application",
      "we have received your application",
      "application received",
      "your application is complete",
      "application complete"
    ];
    if (strong.some(x => t.toLowerCase().includes(x))) return true;

    // Only use the weaker "submitted" signal when paired with application/job
    // language, to avoid triggering on unrelated page text.
    return /\bsubmitted\b/i.test(t) &&
      /\b(application|applying|applied|job|position|candidate)\b/i.test(t);
  }

  function addStyles() {
    if (document.getElementById(ID + "-style")) return;
    const s = document.createElement("style");
    s.id = ID + "-style";
    s.textContent = `
      #${ID}{position:fixed;right:24px;bottom:24px;width:370px;z-index:2147483647;background:#fff;border:1px solid #ddd;border-radius:16px;box-shadow:0 14px 50px rgba(0,0,0,.18);font-family:Inter,Arial,sans-serif;color:#171717;overflow:hidden}
      #${ID} .h{padding:17px 18px 7px;font-size:17px;font-weight:750}
      #${ID} .b{padding:0 18px 14px;color:#555;font-size:13px;line-height:1.45}
      #${ID} .job{margin-top:8px;padding:9px 10px;background:#f6f7f8;border-radius:9px;color:#222;font-weight:650}
      #${ID} .actions{display:flex;gap:8px;padding:12px 18px 16px;background:#fafafa}
      #${ID} button{border:0;border-radius:9px;padding:10px 14px;font-weight:700;cursor:pointer}
      #${ID} .yes{background:#111;color:#fff;flex:1}
      #${ID} .no{background:#e9e9e9;color:#333}
      #${ID} .status{padding:0 18px 16px;font-size:12px;color:#188038}
    `;
    document.head.appendChild(s);
  }

  function titleForPage() {
    const raw = (document.title || "").replace(/\s+/g, " ").trim();
    return raw
      .replace(/\s*[|–—-]\s*(Greenhouse|Lever|Ashby|Workday|Indeed|LinkedIn|SmartRecruiters).*$/i, "")
      .trim() || "Job application";
  }

  async function queueApplication() {
    const data = await chrome.storage.local.get({ pendingApplications: [] });
    const list = Array.isArray(data.pendingApplications) ? data.pendingApplications : [];
    if (list.some(x => x.url === location.href)) return false;

    let company = location.hostname.replace(/^www\./, "");
    list.push({
      id: String(Date.now()) + "-" + Math.random().toString(36).slice(2),
      title: titleForPage(),
      company,
      url: location.href,
      note: "Detected as submitted automatically.",
      appliedAt: new Date().toISOString()
    });
    await chrome.storage.local.set({ pendingApplications: list });
    return true;
  }

  function showPrompt() {
    if (document.getElementById(ID)) return;
    addStyles();

    const box = document.createElement("div");
    box.id = ID;
    box.innerHTML = `
      <div class="h">✨ Tell Jack?</div>
      <div class="b">
        It looks like your application was just submitted.
        <div class="job">${escapeHtml(titleForPage())}</div>
      </div>
      <div class="actions">
        <button class="no">Not now</button>
        <button class="yes">Yes, tell Jack</button>
      </div>
    `;
    document.body.appendChild(box);

    box.querySelector(".no").addEventListener("click", () => {
      box.remove();
    });

    box.querySelector(".yes").addEventListener("click", async () => {
      const yes = box.querySelector(".yes");
      yes.disabled = true;
      yes.textContent = "Saving…";
      try {
        await queueApplication();
        box.innerHTML = `
          <div class="h">✓ Saved for Jack</div>
          <div class="b">I'll offer to update Jack the next time you open Jack & Jill.</div>
          <div class="actions"><button class="yes" style="flex:1">Done</button></div>
        `;
        box.querySelector(".yes").addEventListener("click", () => box.remove());
        setTimeout(() => box.remove(), 3500);
      } catch (e) {
        box.querySelector(".b").insertAdjacentHTML("beforeend",
          `<div style="margin-top:8px;color:#b42318">Couldn't save this application. You can use the extension button manually.</div>`);
        yes.disabled = false;
        yes.textContent = "Yes, tell Jack";
      }
    });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  async function check() {
    if (alreadyChecked || !looksLikeJobSite() || !looksSubmitted()) return;
    alreadyChecked = true;

    // Prevent the same submission page from prompting repeatedly on reload.
    const key = location.origin + location.pathname + location.search;
    const seen = await chrome.storage.local.get({ [STORAGE_KEY]: {} });
    const lastSeen = seen[STORAGE_KEY][key] || 0;

    // Suppress repeated prompts for 24 hours, but allow the same URL to
    // become detectable again later.
    if (Date.now() - lastSeen < 24 * 60 * 60 * 1000) return;

    const next = seen[STORAGE_KEY];
    next[key] = Date.now();

    // Keep this small so the local extension store does not grow forever.
    for (const [k, v] of Object.entries(next)) {
      if (Date.now() - v > 7 * 24 * 60 * 60 * 1000) delete next[k];
    }

    await chrome.storage.local.set({ [STORAGE_KEY]: next });
    showPrompt();
  }

  setTimeout(check, 1200);

  const observer = new MutationObserver(() => {
    if (!alreadyChecked) check();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();