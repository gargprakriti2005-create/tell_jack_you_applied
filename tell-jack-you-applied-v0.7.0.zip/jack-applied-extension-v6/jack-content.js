(() => {
  const STYLE_ID = "jack-applied-tracker-style";
  const MODAL_ID = "jack-applied-tracker-modal";
  let observerStarted = false;

  function isChatPage() {
    const els = [...document.querySelectorAll("textarea, input, [contenteditable='true']")];
    return els.some(el => {
      const p = (el.getAttribute("placeholder") || "").toLowerCase();
      const aria = (el.getAttribute("aria-label") || "").toLowerCase();
      return p.includes("ask jack") || aria.includes("ask jack");
    });
  }

  function addStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = `
      #${MODAL_ID}{position:fixed;right:24px;bottom:24px;width:390px;z-index:2147483647;background:#fff;border:1px solid #ddd;border-radius:16px;box-shadow:0 14px 50px rgba(0,0,0,.18);font-family:Inter,Arial,sans-serif;color:#171717;overflow:hidden}
      #${MODAL_ID} .jat-head{padding:17px 18px 9px;font-size:17px;font-weight:750}
      #${MODAL_ID} .jat-body{padding:0 18px 14px;color:#555;font-size:13px;line-height:1.45}
      #${MODAL_ID} .jat-list{margin:9px 0 0;padding:0;list-style:none;max-height:180px;overflow:auto}
      #${MODAL_ID} .jat-item{padding:8px 0;border-top:1px solid #eee}
      #${MODAL_ID} .jat-title{font-weight:700;color:#222}
      #${MODAL_ID} .jat-meta{font-size:11px;color:#777;margin-top:2px;word-break:break-all}
      #${MODAL_ID} .jat-actions{display:flex;gap:8px;padding:12px 18px 16px;background:#fafafa}
      #${MODAL_ID} button{border:0;border-radius:9px;padding:10px 14px;font-weight:700;cursor:pointer}
      #${MODAL_ID} .jat-yes{background:#111;color:#fff;flex:1}
      #${MODAL_ID} .jat-no{background:#e9e9e9;color:#333}
      #${MODAL_ID} .jat-status{padding:0 18px 16px;font-size:12px;color:#188038}
    `;
    document.head.appendChild(s);
  }

  async function getPending() {
    const { pendingApplications = [] } =
      await chrome.storage.local.get({ pendingApplications: [] });
    return pendingApplications;
  }

  function esc(s) {
    return String(s || "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function makeMessage(items) {
    const lines = [
      "Quick update: here are the jobs I’ve applied to since my last update.",
      ""
    ];
    items.forEach((x, i) => {
      lines.push(`${i + 1}. ${x.title || "Job application"} — ${x.company || "Unknown site"}`);
      lines.push(`   ${x.url}`);
      if (x.note) lines.push(`   Note: ${x.note}`);
      lines.push(`   Applied: ${new Date(x.appliedAt).toLocaleDateString()}`);
      lines.push("");
    });
    lines.push("Please keep these applications in mind when helping me with my job search.");
    return lines.join("\n");
  }

  function findComposer() {
    const els = [...document.querySelectorAll("textarea, input, [contenteditable='true']")];
    return els.find(el => {
      const p = (el.getAttribute("placeholder") || "").toLowerCase();
      const aria = (el.getAttribute("aria-label") || "").toLowerCase();
      return p.includes("ask jack") || aria.includes("ask jack");
    }) || null;
  }

  function findSendButton(composer) {
    const candidates = [...document.querySelectorAll("button, [role='button']")];
    return candidates.find(b => {
      const label = `${b.getAttribute("aria-label") || ""} ${b.title || ""} ${b.getAttribute("data-testid") || ""} ${b.textContent || ""}`.toLowerCase();
      return /send|submit/.test(label) && !b.disabled;
    }) || null;
  }

  function composerIsEmpty(el) {
    if (!el) return true;
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      return !(el.value || "").trim();
    }
    return !(el.innerText || el.textContent || "").trim();
  }

  function setComposerValue(el, text) {
    el.focus();

    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      const proto = Object.getPrototypeOf(el);
      const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
      if (descriptor?.set) descriptor.set.call(el, text);
      else el.value = text;

      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }

    // contenteditable / ProseMirror / similar editors
    el.textContent = text;
    el.dispatchEvent(new InputEvent("input", {
      bubbles: true,
      inputType: "insertText",
      data: text
    }));
  }

  async function waitForComposerToClear(composer, timeoutMs = 3000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      if (composerIsEmpty(composer)) return true;
      await new Promise(r => setTimeout(r, 150));
    }
    return false;
  }

  async function sendToJack() {
    const items = await getPending();
    const composer = findComposer();
    if (!composer) throw new Error("I couldn't find Jack's chat box.");

    const message = makeMessage(items);
    setComposerValue(composer, message);

    await new Promise(r => setTimeout(r, 400));

    const send = findSendButton(composer);

    if (send) {
      send.click();
    } else {
      const form = composer.closest("form");
      if (form && typeof form.requestSubmit === "function") {
        form.requestSubmit();
      } else {
        throw new Error("I found Jack's chat box but couldn't find its Send button.");
      }
    }

    // Do not report success just because a click happened. Jack's UI should
    // consume the message and clear the composer. If it doesn't, keep the
    // queued applications so nothing gets lost.
    const cleared = await waitForComposerToClear(composer, 3000);
    if (!cleared) {
      throw new Error("Jack did not confirm that the message was sent.");
    }

    return true;
  }

  async function showPrompt(items) {
    if (!items.length || document.getElementById(MODAL_ID) || !isChatPage()) return;
    addStyles();

    const modal = document.createElement("div");
    modal.id = MODAL_ID;
    modal.innerHTML = `
      <div class="jat-head">✨ Update Jack about what you've been up to?</div>
      <div class="jat-body">
        I have <strong>${items.length}</strong> saved application${items.length === 1 ? "" : "s"} waiting.
        <ul class="jat-list">
          ${items.map(x => `
            <li class="jat-item">
              <div class="jat-title">${esc(x.title || "Job application")}</div>
              <div class="jat-meta">${esc(x.company || "")} · ${new Date(x.appliedAt).toLocaleDateString()}</div>
            </li>`).join("")}
        </ul>
      </div>
      <div class="jat-actions">
        <button class="jat-no">Not now</button>
        <button class="jat-yes">Yes, update Jack</button>
      </div>
    `;
    document.body.appendChild(modal);

    modal.querySelector(".jat-no").addEventListener("click", () => modal.remove());
    modal.querySelector(".jat-yes").addEventListener("click", async () => {
      const yes = modal.querySelector(".jat-yes");
      yes.disabled = true;
      yes.textContent = "Sending…";
      try {
        await sendToJack();
        await chrome.storage.local.set({ pendingApplications: [] });
        await chrome.action.setBadgeText({ text: "" });

        // Give the user a clear confirmation, then let them dismiss it.
        // It also disappears automatically after a short delay.
        modal.innerHTML = `
          <div class="jat-head">✓ Done — Jack was updated</div>
          <div class="jat-status">Your saved applications were sent in the chat.</div>
          <div class="jat-actions">
            <button class="jat-yes" style="flex:1">Done</button>
          </div>
        `;

        const doneButton = modal.querySelector(".jat-yes");
        doneButton.addEventListener("click", () => modal.remove());
        setTimeout(() => {
          if (document.getElementById(MODAL_ID)) modal.remove();
        }, 3500);
      } catch (e) {
        yes.disabled = false;
        yes.textContent = "Yes, update Jack";
        const body = modal.querySelector(".jat-body");
        if (body) body.insertAdjacentHTML("beforeend",
          `<div style="margin-top:10px;color:#b42318">I couldn't send it automatically. Keep this tab open and try again.</div>`);
      }
    });
  }

  async function maybeShow() {
    if (!isChatPage()) return;
    const items = await getPending();
    if (items.length) showPrompt(items);
  }

  // Jack is a dynamic app. Retry for a short period so the prompt still
  // appears if the chat composer mounts after the initial page load.
  let attempts = 0;
  const retryTimer = setInterval(async () => {
    attempts++;
    await maybeShow();
    if (document.getElementById(MODAL_ID) || attempts >= 30) {
      clearInterval(retryTimer);
    }
  }, 500);

  const observer = new MutationObserver(() => {
    if (!observerStarted) {
      observerStarted = true;
      setTimeout(maybeShow, 250);
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();