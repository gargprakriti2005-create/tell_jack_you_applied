chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get({ pendingApplications: [] });
});

// If a Jack tab is opened, the content script handles the in-page prompt.
// This listener is intentionally lightweight; the application data stays
// local in chrome.storage.local.
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab.url) return;
  if (!/https:\/\/([^/]+\.)?jackandjill\.ai\//i.test(tab.url)) return;

  const { pendingApplications = [] } =
    await chrome.storage.local.get({ pendingApplications: [] });

  if (pendingApplications.length) {
    try {
      await chrome.action.setBadgeText({ tabId, text: String(Math.min(pendingApplications.length, 99)) });
    } catch {}
  }
});