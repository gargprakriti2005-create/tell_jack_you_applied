# Tell Jack You Applied — v0.7.0

This version uses a local queue instead of trying to log into Jack from the extension.

## Flow

1. Open a job/application page.
2. Click the extension.
3. Click **I applied**.
4. The extension stores the application locally in Chrome.
5. Later, open your logged-in Jack & Jill app.
6. When the Jack chat box is visible, the extension shows:
   **"Update Jack about what you've been up to?"**
7. Click **Yes, update Jack**.
8. The extension fills Jack's chat with all queued applications and attempts to send it.
9. The queue is cleared only after the send action succeeds.

The extension does not ask for your Jack password and does not send anything to a server owned by this extension.

## Install

1. Unzip the folder.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Choose **Load unpacked**.
5. Select this folder.
6. Pin the extension.

## Notes

- Applications are stored in `chrome.storage.local`, which persists across browser restarts.
- The Jack integration relies on the visible chat UI. If Jack changes its frontend HTML, the selectors may need an update.
- The extension only runs its Jack-specific content script on `*.jackandjill.ai`.


## v0.3 fix
The popup now explicitly requests the `tabs` permission for reliable access to the active page URL/title and shows visible success/error messages. It also verifies the data was written to `chrome.storage.local`.


## v0.4
After applications are successfully sent to Jack, the popup changes to **Done — Jack was updated** with a **Done** button. It also automatically disappears after 3.5 seconds. The saved queue is cleared only after the send action completes.


## v0.5 — automatic submission detection

On supported job/application pages, the extension watches for a clear "application submitted" / "thank you for applying" style confirmation. When it sees one, it shows:

**✨ Tell Jack?**

**Yes, tell Jack** saves the application to the local queue. **Not now** dismisses it.

The extension does not automatically claim an application from an ordinary page just because it contains the word "submitted"; it uses job-site signals and a set of application-submission phrases. Because every job site is different, some sites may require a site-specific detector later.


## v0.7 — renamed for the Chrome Web Store

- Renamed the extension to **Tell Jack You Applied**.
- Incremented the extension version to **0.7.0** for the Chrome Web Store update.
- Updated the extension action title and short description.

## v0.6 audit/fixes

- Fixed the package version so it matches the release.
- Removed the unused notifications permission.
- The Jack queue is **not cleared merely because a button was clicked**. The extension now requires the composer to clear after submission; otherwise the applications remain queued.
- Added a form-submit fallback when a visible Send button cannot be found.
- Added retries for Jack's dynamically loaded chat composer.
- Submission-page prompts are suppressed for 24 hours per exact page, with old detection records cleaned up.
